library(ggiraph)
library(plotly)
library(shiny)
library(magrittr)
library(foreign)
library(devtools)
library(sf)
library(tmap)
library(rgdal)
library(maps)
library(maptools)
library(sp)
library(stringr)
library(webshot)
library(RCurl)
library(magick)
library(splashr)
library(RSelenium)
library(tidyverse)
library(V8)
library(rvest)
library(stringr)
library(plyr)
library(dplyr)
library(ggvis)
library(knitr)
library(XML)
library(methods)
library(rsconnect)
library(reshape2)

source("graber/helper.R") 

# Define UI for application that draws a histogram
ui <- fluidPage(
   
    # Application title
    titlePanel("Względne ryzyko zarażenia koronawirusem"),
    
    tags$p("Raporty na temat przypadków zarażenia koronawirusem zwykle zawierają liczbę odnotowanych przypadków w danym województwie (Zakładka 1). Jednak 
           taka informacja jest niewystarczająca, a wręcz myląca w kontekście oceny ryzyka zarażenia w danym województwie. Wynika to z faktu, że
           liczba odnotowanych przypadków w naturalny sposób będzie nawiązywała do liczby ludności. W celu rozwiązania tego problemu potrzebne
           jest odwołanie się do podstawowych koncepcji epidemiologii, w których użyteczną informację stanowi liczba przypadków odniesiona do liczby mieszkańców.
           W ten sposób możliwe jest obliczenie wartości oczekiwanej dla każdego województwa (Zakładka 2) i porównanie jej z obserwowaną liczbą przypadków. W ten sposób możemy
           otrzymać względne ryzyko dla każdego województwa i wygenerować odpowiednią mapę (Zakładka 3). Wartości większe od 1 na mapie ryzyka oznaczają większe niż przeciętne ryzyko zachorowania. 
           Może to wskazywać na istnienie skupisk zarażenia lub zwiększonej liczby osób podatnych na zarażenie, na przykład osób starszych."),
    
    tags$p("Literatura: 
    Bivand, R. S., Pebesma, E. J., Gomez-Rubio, V., & Pebesma, E. J. (2008). Applied spatial data analysis with R (Vol. 747248717). New York: Springer"
           ),
    
    tags$p("Uwaga: statystyki są aktualizowane nieregularnie. Możliwe jest jednak wykonanie obliczeń i map na podstawie własnego pliku.
    W tym celu należy uzyskać dane ze",
    
    tags$a(href="https://www.gov.pl/web/koronawirus/wykaz-zarazen-koronawirusem-sars-cov-2", "strony"    ), 
    
    "i w tej samej kolejności
    zapisać je do pliku z rozszerzeniem .csv (można to zrobić w Excelu lub Notatniku). Proponowana jest następująca struktura pliku (pierwsze trzy wiersze):"),

    tags$code("przypadki_obserwowane;czas"), tags$br(),
    tags$code("134;2020-03-24 19:14:37 CET"),  tags$br(),
    tags$code("22;2020-03-24 19:14:37 CET"),   tags$br(),
    tags$p("Gdy plik będzie wyglądał w ten sposób, należy zaznaczyć Nagłówek, jako separator wybrać Średnik, a w polu Cudzysłów wybrać Brak ."),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            actionButton("runif", "Oblicz"),
            
            tags$hr(),
            
            fileInput('file1', 'Wybierz plik',
                      accept = c(
                        'text/csv',
                        'text/comma-separated-values',
                        'text/tab-separated-values',
                        'text/plain',
                        '.csv',
                        '.tsv'
                      )
            ),
            tags$hr(),
            checkboxInput('header', 'Nagłówek', TRUE),
            radioButtons('sep', 'Separator',
                         c(Przecinek=',',
                           Średnik=';',
                           Tabulator='\t'),
                         ','),
            radioButtons('quote', 'Cudzysłów',
                         c(Brak='',
                           'Podwójny cudzysłów'='"',
                           'Pojedyńczy cudzysłów'="'"),
                         '"')
        ),

        # Show a plot of the generated distribution
        mainPanel(
                tabsetPanel(
                tabPanel("1. Obserwowana liczba przypadków", textOutput("suma"), textOutput("aktu"), plotOutput("map1") ),
                tabPanel("2. Oczekiwana liczba przypadków",  plotOutput("map2") ),
                tabPanel("3. Przypadki na 100 tys. mieszkańców",  plotOutput("map3") ),
                tabPanel("4. Względne ryzyko",   plotOutput("map4") ),
                tabPanel("5. Względne ryzyko w czasie", "Uwaga 1: ładowanie może trwać kilkadziesiąt sekund", tags$br(),
                         "Uwaga 2: niewielkie różnice między względnym ryzykiem na wykresie i na mapach wynikają z faktu, że dane sanepidu mazowieckiego (użyte do odtworzenia historii) różnią się od danych ze strony rządowej", plotlyOutput("map5") ),
                tabPanel("6. Skumulowane względne ryzyko w czasie", "Uwaga 1: ładowanie może trwać kilkadziesiąt sekund", tags$br(),
                                                         "Uwaga 2: niewielkie różnice między względnym ryzykiem na wykresie i na mapach wynikają z faktu, że dane sanepidu mazowieckiego (użyte do odtworzenia historii) różnią się od danych ze strony rządowej", plotlyOutput("map6") )
  
            ) 
           #plotOutput("distPlot")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
        
        observeEvent(input$runif, {
         
        inFile <- input$file1
     
        if (is.null(inFile))
        {
          dane<-read.csv2("data/data2.csv", header=TRUE, dec=".")
        }
        else{
          dane<-read.csv(inFile$datapath, header = input$header, sep = input$sep, quote = input$quote)
          ludnosc <- c(2865000, 2060000, 2148000, 1004000, 2466000, 3349000, 5385000, 948808, 2129000, 1193000, 
                       2295000, 4501000, 1263000, 1408000, 3466000, 1679000 )
          dane<-dplyr::mutate(dane, ludnosc)
          
          ratio <- sum(dane$przypadki_obserwowane)/sum(dane$ludnosc)
          przypadki_oczekiwane<-(dane$ludnosc)*ratio
          dane<-dplyr::mutate(dane, przypadki_oczekiwane)
         
          SMR<-dane$przypadki_obserwowane/dane$przypadki_oczekiwane
          dane<-dplyr::mutate(dane, SMR)
          
          Obserwowane100<-(dane$przypadki_obserwowane/dane$ludnosc)*100000
          dane<-dplyr::mutate(dane, Obserwowane100)
        }
        
        Obserwowane100 <- c(dane$Obserwowane100[12],
                         dane$Obserwowane100[8], 
                         dane$Obserwowane100[15], 
                         dane$Obserwowane100[16], 
                         dane$Obserwowane100[13], 
                         dane$Obserwowane100[2], 
                         dane$Obserwowane100[10], 
                         dane$Obserwowane100[1], 
                         dane$Obserwowane100[9], 
                         dane$Obserwowane100[6], 
                         dane$Obserwowane100[11], 
                         dane$Obserwowane100[14], 
                         dane$Obserwowane100[5], 
                         dane$Obserwowane100[7], 
                         dane$Obserwowane100[3], 
                         dane$Obserwowane100[4] )
        
          obserwowane <- c(dane$przypadki_obserwowane[12],
                           dane$przypadki_obserwowane[8], 
                           dane$przypadki_obserwowane[15], 
                           dane$przypadki_obserwowane[16], 
                           dane$przypadki_obserwowane[13], 
                           dane$przypadki_obserwowane[2], 
                           dane$przypadki_obserwowane[10], 
                           dane$przypadki_obserwowane[1], 
                           dane$przypadki_obserwowane[9], 
                           dane$przypadki_obserwowane[6], 
                           dane$przypadki_obserwowane[11], 
                           dane$przypadki_obserwowane[14], 
                           dane$przypadki_obserwowane[5], 
                           dane$przypadki_obserwowane[7], 
                           dane$przypadki_obserwowane[3], 
                           dane$przypadki_obserwowane[4] )
          
          oczekiwane <- c(dane$przypadki_oczekiwane[12],
                          dane$przypadki_oczekiwane[8], 
                          dane$przypadki_oczekiwane[15], 
                          dane$przypadki_oczekiwane[16], 
                          dane$przypadki_oczekiwane[13], 
                          dane$przypadki_oczekiwane[2], 
                          dane$przypadki_oczekiwane[10], 
                          dane$przypadki_oczekiwane[1], 
                          dane$przypadki_oczekiwane[9], 
                          dane$przypadki_oczekiwane[6], 
                          dane$przypadki_oczekiwane[11], 
                          dane$przypadki_oczekiwane[14], 
                          dane$przypadki_oczekiwane[5], 
                          dane$przypadki_oczekiwane[7], 
                          dane$przypadki_oczekiwane[3], 
                          dane$przypadki_oczekiwane[4] )
          
          riskvec <- c(dane$SMR[12],
                       dane$SMR[8], 
                       dane$SMR[15], 
                       dane$SMR[16], 
                       dane$SMR[13], 
                       dane$SMR[2], 
                       dane$SMR[10], 
                       dane$SMR[1], 
                       dane$SMR[9], 
                       dane$SMR[6], 
                       dane$SMR[11], 
                       dane$SMR[14], 
                       dane$SMR[5], 
                       dane$SMR[7], 
                       dane$SMR[3], 
                       dane$SMR[4] )
          
          mapaw <- st_read("data/Wojewodztwa.shp")
          mapaw$Obserwowane         <-obserwowane
          mapaw$Oczekiwane          <-oczekiwane
          mapaw$Obserwowane100      <-Obserwowane100
          mapaw$Ryzyko_SMR          <- riskvec
          mapaw$Oczekiwanef         <- as.character(formatC(mapaw$Oczekiwane,  format = "f", digits = 1))
          mapaw$Obserwowane100f        <- as.character(formatC(mapaw$Obserwowane100,  format = "f", digits = 1))
          mapaw$RelativeRounded     <-as.character(round(mapaw$Ryzyko_SMR, 2))
          
          dane<-read.csv2("data/data2.csv", header=TRUE, dec=".")
          inFile <- dane
          if (is.null(inFile))
            return(NULL)
          read.csv2("data/data2.csv", header=TRUE, dec=".")
          
          output$suma<- renderText(paste("Razem:", sum(mapaw$Obserwowane), "\n"))
          output$aktu<- renderText(paste("Data aktualizacji:", dane$czas[13]))
          output$map1<- renderPlot( tm_shape(mapaw) + tm_polygons('blue') +tm_text("Obserwowane", size=3)     )
          output$map2<- renderPlot( tm_shape(mapaw) + tm_polygons('blue') +tm_text("Oczekiwanef", size=2.5)   )
          output$map3<- renderPlot( tm_shape(mapaw) + tm_polygons('Obserwowane100') +tm_text("Obserwowane100f", size=2.5)   )
          output$map4<- renderPlot( tm_shape(mapaw) + tm_polygons('Ryzyko_SMR')+ tm_text('RelativeRounded', size=1.5  )      ) 
          output$map5<- renderPlotly(  ggplotly(wykres1)   )
          output$map6<- renderPlotly(  ggplotly(wykres2)   )
        })
  }

# Run the application 
shinyApp(ui = ui, server = server)
