library(DCluster)
library(plotly)
library(shiny)
library(magrittr)
library(foreign)
library(devtools)
library(sf)
library(tmap)
library(rgdal)
library(maps)
library(maptools)
library(sp)
library(stringr)
library(webshot)
library(RCurl)
library(magick)
library(splashr)
library(RSelenium)
library(tidyverse)
library(V8)
library(rvest)
library(stringr)
library(plyr)
library(dplyr)
library(ggvis)
library(knitr)
library(XML)
library(methods)
library(rsconnect)
library(reshape2)

szereg<-read.csv("data/szereg.csv", sep=";", dec=".", header = TRUE, row.names = 1, check.names = FALSE)
colnames(szereg)<- as.Date(colnames(szereg), "%d.%m.%Y" )

relrisk = function(szereg){
  
  ludnosc<- c(2865000, 2060000, 2148000, 1004000, 2466000, 3349000, 5385000, 948808, 2129000, 1193000, 2295000, 4501000, 1263000, 1408000, 3466000, 1679000 )
  
  sumaj<-c()
  
  for(i in 1:ncol(szereg)){
    sumaj[i]<-sum(szereg[,i])
  }
  
  ratio<-c()
  
  for(i in 1:ncol(szereg)){
    ratio[i]<-sumaj[i]/sum(ludnosc)
  }
  
  oczek<-data.frame(matrix(ncol=ncol(szereg), nrow=0))
  colnames(oczek) <- colnames(szereg)
  
  for(i in 1:16){
    for(j in 1:ncol(szereg)){
      oczek[i,j]<-ludnosc[i]*ratio[j]
    }
  }
  
  SMR=szereg/oczek
  return(SMR)
}

relrisk_cum = function(szereg){
  
  ludnosc<- c(2865000, 2060000, 2148000, 1004000, 2466000, 3349000, 5385000, 948808, 2129000, 1193000, 2295000, 4501000, 1263000, 1408000, 3466000, 1679000 )
  
  sumaj<-c()
  
  for(i in 1:ncol(szereg)){
    sumaj[i]<-sum(szereg[,i])
  }
  
  sumak<-c(sumaj[1])
  
  for(i in 2:ncol(szereg)){
    sumak[i]<-sumak[i-1]+sumaj[i]
  }
  
  ratio<-c()
  
  for(i in 1:ncol(szereg)){
    ratio[i]<-sumak[i]/sum(ludnosc)
  }
  
  oczek<-data.frame(matrix(ncol=ncol(szereg), nrow=0))
  colnames(oczek) <- colnames(szereg)

  for(i in 1:16){
    for(j in 1:ncol(szereg)){
      oczek[i,j]<-ludnosc[i]*ratio[j]
    }
  }
  
  sumw<-data.frame(matrix(ncol=ncol(szereg), nrow=0))
  colnames(sumw) <- colnames(szereg)
  
  for(i in 1:16){
    sumw[i,1]<-szereg[i,1]
  }
  
  for(i in 1:16){
    for(j in 2:ncol(szereg)){
      sumw[i,j]<-sumw[i,j-1]+szereg[i,j]
    }
  }
  SMR=sumw/oczek
  return(SMR)
}

relriskdf2<- relrisk(szereg)
relriskdf2<-dplyr::mutate(relriskdf2, wojewodztwa)

relriskdfnames2 <- relriskdf2 %>%
  dplyr::select(wojewodztwa, everything())%>%
  dplyr::select(-c("2020-03-04",   "2020-03-05",   "2020-03-06",   "2020-03-07",   "2020-03-08",   "2020-03-09",   "2020-03-10",  "2020-03-11",  "2020-03-12"))

mdf2 <- melt(relriskdfnames2, id.vars="wojewodztwa", value.name="Relative_Risk_SMR", variable.name="Data")

wykres1<-ggplot(data=mdf2, aes(x=Data, y=Relative_Risk_SMR, group = wojewodztwa, colour = wojewodztwa)) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))



relriskdf<- relrisk_cum(szereg)
wojewodztwa<- c("dolnoslaskie", "kujawsko-pomorskie", "lubelskie", "lubuskie", "lodzkie", "malopolskie", "mazowieckie", "opolskie", "podkarpackie", "podlaskie", "pomorskie", "slaskie",
                "swietokrzyskie", "warminsko-mazurskie", "wielkopolskie", "zachodniopomorskie")

relriskdf<-dplyr::mutate(relriskdf, wojewodztwa)
relriskdfnames <- relriskdf %>%
  dplyr::select(wojewodztwa, everything())%>%
  dplyr::select(-c("2020-03-04",   "2020-03-05",   "2020-03-06",   "2020-03-07",   "2020-03-08",   "2020-03-09",   "2020-03-10",  "2020-03-11",  "2020-03-12"))
  
  
mdf <- melt(relriskdfnames, id.vars="wojewodztwa", value.name="Cumulative_Relative_Risk_SMR", variable.name="Data")

wykres2<-ggplot(data=mdf, aes(x=Data, 
                              y=Cumulative_Relative_Risk_SMR, 
                              group = wojewodztwa, 
                              colour = wojewodztwa
)) +
  geom_line(size=0.5) +
  geom_point( size=1, shape=21, fill="white")+
  theme(axis.text.x=element_text(angle = -90, hjust = 0))






